export class Customer{
    name:string = "";
    age:number = 0;
    amount:number = 0;
}