import { NgModule } from '@angular/core';
import {Config} from "../Common/Config.app"
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerComponent } from './CustomerApp.CustomerComponent';
import { RouterModule } from '@angular/router';
import { CustomerRoutes } from './CustomerApp.Routing';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Customer, CustomerType1, CustomerType2 } from './CustomerApp.CustomerModel';
import { MyGrid } from 'src/UserControl/UserControl.grid';
var GlobalVariable:string = "hello";
@NgModule({
  declarations: [
    CustomerComponent , MyGrid
  ],
  imports: [
    CommonModule , 
    FormsModule,ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forChild(CustomerRoutes)
  ],
  providers: [ Config,{
    
    provide:Customer , useClass :CustomerType1 
  },
  {
    
    provide:GlobalVariable , useValue :"test123" 
  }],
  bootstrap: [CustomerComponent]
})
export class CustomerModule { }
