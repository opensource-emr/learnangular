import { Component } from '@angular/core';
import {Customer} from "./CustomerApp.CustomerModel"
import {HttpClient} from "@angular/common/http"
@Component({
  templateUrl: './CustomerApp.CustomerAdd.html'
})
export class CustomerComponent {
  customerObj:Customer = new Customer();
  customerObjs:Array<Customer> = new Array<Customer>();
 
  constructor(public httpClient:HttpClient){
    this.Get();
  }
  Add(){
    this.customerObjs.push(this.customerObj);
    this.customerObj = new Customer();// cleared the object
    //this.customerObj.formgroup.updateValueAndValidity(); // forcibly
  }
  SubmitAll(){
    this.customerObjs.forEach(element => {
    var customerDto:any = {};
    customerDto.name = element.name;
    customerDto.age = element.age;
    customerDto.amount = element.amount;
    customerDto.email = element.email;
    
    var observable =  this.httpClient.post("http://localhost:3000/Customer",
     customerDto);
      observable.subscribe(res=>this.SuccessObserverPost(res),
                res=>this.ErrorObserver(res));
    });
  }
  Get(){
    var observable =  this.httpClient.get("http://localhost:3000/Customer");
      observable.subscribe(res=>this.SuccessObserverGet(res),
                res=>this.ErrorObserver(res));
    
  }
  SuccessObserverGet(res){
    this.customerObjs = res;
  }
  SuccessObserverPost(res){
    this.Get();
  }
  ErrorObserver(res){
    console.log(res);
  }
}
