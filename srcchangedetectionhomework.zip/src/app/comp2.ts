import { Component, ViewChild, ElementRef, Input, ViewChildren, QueryList, ContentChild, ContentChildren, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'comp2',
    templateUrl: 'comp2.html',
    changeDetection: ChangeDetectionStrategy.OnPush

  })
  export class comp2{
    
    
    
     
      ngDoCheck()	{
        console.log("comp2 check ");
      }
     
  
  }