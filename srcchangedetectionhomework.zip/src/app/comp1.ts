import { Component, ViewChild, ElementRef,
        Input, ViewChildren, 
        QueryList, ContentChild, 
        ChangeDetectionStrategy, ChangeDetectorRef } 
        from '@angular/core';

import {comp2} from "./comp2"
import {Observable,timer } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './comp1.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class comp1 {
  @Input() SomeData:string="test123";
  constructor(public cd:ChangeDetectorRef){

  }
  
  ngDoCheck()	{
    console.log("comp1 check ");
  }
}

