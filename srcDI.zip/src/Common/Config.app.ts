export class Config{
    apiUrl:string = "http://localhost:3000/Customer";
}