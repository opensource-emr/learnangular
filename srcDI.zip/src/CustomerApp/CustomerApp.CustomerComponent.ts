import { Component } from '@angular/core';
import {Customer, CustomerType1} from "./CustomerApp.CustomerModel"
import {HttpClient} from "@angular/common/http"
import { Config } from 'src/Common/Config.app';
@Component({
  templateUrl: './CustomerApp.CustomerAdd.html'
})
export class CustomerComponent {
  customerObj:Customer = null;
  customerObjs:Array<Customer> = new Array<Customer>();
 
  
  Add(){
    this.customerObjs.push(this.customerObj);
    this.customerObj = new Customer();// cleared the object
    //this.customerObj.formgroup.updateValueAndValidity(); // forcibly
  }
  constructor(public httpClient:HttpClient,
    public _customer:Customer ,
    public _config:Config){
      this.customerObj = _customer;
    this.Get();
  }
  SubmitAll(){
    this.customerObjs.forEach(element => {
    var customerDto:any = {};
    customerDto.name = element.name;
    customerDto.age = element.age;
    customerDto.amount = element.amount;
    customerDto.email = element.email;
    var observable =  this.httpClient.post(this._config.apiUrl,
     customerDto);
      observable.subscribe(res=>this.SuccessObserverPost(res),
                res=>this.ErrorObserver(res));
    });
  }
  Get(){
    var observable =  this.httpClient.get(this._config.apiUrl);
      observable.subscribe(res=>this.SuccessObserverGet(res),
                res=>this.ErrorObserver(res));
    
  }
  SuccessObserverGet(res){
    this.customerObjs = res;
  }
  SuccessObserverPost(res){
    // again GET call
    this.Get();
  }
  ErrorObserver(res){
    console.log(res);
  }
}
