import { CustomerComponent } from './CustomerApp.CustomerComponent';


export const CustomerRoutes = [
    { path: 'Add', component: CustomerComponent}
]
// Case sensitive -- turn off
// Web server