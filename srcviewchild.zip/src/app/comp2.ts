import { Component, ViewChild, ElementRef, Input, ViewChildren, QueryList, ContentChild, ContentChildren } from '@angular/core';

@Component({
    selector: 'comp2',
    templateUrl: 'comp2.html'
  })
  export class comp2{
    @Input() id !: string;
    @ContentChild("projectedcontent",{ static: true }) projectedcontent:ElementRef ;  //ContentChild with only selector
    @ContentChildren("projectedcontent") projectedcontents: QueryList<ElementRef>;
  
  ngAfterContentInit() {
    alert(this.projectedcontent.nativeElement.innerHTML);
    this.projectedcontents.toArray().forEach(element => {
        console.log(element.nativeElement.innerHTML);
    });
  }

  Click(){
    alert(this.id);
  }
  }