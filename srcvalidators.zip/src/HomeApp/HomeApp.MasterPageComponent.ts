import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './HomeApp.MasterPage.html'
})
export class MasterPageComponent {
  
}
